using System;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace myWebApp.Models
{

  public  class Product
    {
        public string id { get; set; }      
        public string maker { get; set; }
        [JsonPropertyName("img")]
        public string img { get; set; }
        public string url { get; set; }
        public string title { get; set; }
        public string description { get; set; }

        public int[] ratings { get; set; }

        public override string ToString()=>JsonSerializer.Serialize<Product>(this);
        
    }    
}
