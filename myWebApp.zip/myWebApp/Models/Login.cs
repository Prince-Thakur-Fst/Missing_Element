using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace myWebApp.Models
{
    public class LoginModel
    {

       [EmailAddress]
       [JsonPropertyName("EmailAddress")]
    public string[] EmailAddress { get; set; }
       [DataType(DataType.Password)] 
       [JsonPropertyName("PassWord")]
        public string[] PassWord { get; set; }
    
 
        
    }
}
