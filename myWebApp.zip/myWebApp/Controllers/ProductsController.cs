using System.Collections.Generic;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.AspNetCore.Mvc;
using myWebApp.Models;

using myWebApp.Services;
namespace myWebApp.Controller
{
[Route("[controller]")]
[ApiController]
public class ProductsController :ControllerBase
{
    
    public ProductsController(JsonFileProductService productService)
    {
        this.ProductService=productService;
    }
    public JsonFileProductService ProductService{get;}
        public object FormsAuthentication { get; private set; }

        [HttpGet]
    public IEnumerable <Product> Get()

    {
        return ProductService.GetProducts();
    }

    [Route("rate")]
    [HttpGet]
    public ActionResult GetAction(
        [FromQuery]string id,
        [FromQuery]int rating)
    {
        ProductService.AddRating( id,rating);
        return Ok();
    }


        [HttpGet]
        public ActionResult checkUser()
        {
            Response.Redirect("https://www.google.co.in/?gfe_rd=cr&ei=BpszVKXmIsPN8gfBi4GABg&gws_rd=ssl"); 
                return Ok("index");
        }

               
             public class RatingRequest
        {
            public string ProductId { get; set; }
            public int Rating { get; set; }
        }   
 
  }
}